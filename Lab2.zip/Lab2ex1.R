#BIOL933
#Lab 2
#Example 1

#import, then inspect the data
str(ques1_dat, give.attr=F)

#convert the data into a dataframe, then reinspect
ques1_dat<-as.data.frame(ques1_dat)
str(ques1_dat, give.attr=F)

# Tell R that "Sample" is a FACTOR
ques1_dat$Sample<-as.factor(ques1_dat$Sample)
str(ques1_dat, give.attr=F)

# Find the requested means
means <- aggregate(ques1_dat$Meas, list(ques1_dat$Sample), mean)

# Find other useful info...
ids <- unique(ques1_dat$Sample)
ns <- aggregate(ques1_dat$Meas, list(ques1_dat$Sample), length)

# Compile the results into a summary dataframe
summary = data.frame(ids,means$x,ns$x)
names(summary)[1:3] <- c("Sample","Mean","n")
summary
